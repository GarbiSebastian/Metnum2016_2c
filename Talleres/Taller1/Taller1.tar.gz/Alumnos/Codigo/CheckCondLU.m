function ret = CheckCondLU(A)

tic
ret = 0;
for i = _______ % Completar rango para i (help size)
    if ___________, % Completar condicion de corte. Si pasa, la funcion retorna false.
        return;
    end
end
ret = 1;
toc
